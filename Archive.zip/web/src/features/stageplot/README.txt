Stage Plot MVP:
- Simple draggable nodes within a fixed container
- Persists to /api/stageplots/:contextId
- Future: snap-to-grid, types, IO mapping, timeline integration
